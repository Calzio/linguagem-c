#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <ctype.h>

int main () {
	
	setlocale(LC_ALL, "");
	
	int valor, somaGeral = 0, somaPares = 0, contGeral = 0;
	int pares = 0, impares = 0, maiorNum = 0, menorNum = 0;
	float medGeral, medPares;
	
	printf("Digite um n�mero: ");
	scanf("%i",&valor);
	
	while (valor != 0) {
		if(valor > 0) {
			contGeral++;
			somaGeral += valor;
		
		if (valor % 2 == 0) {
			pares++;
			somaPares += valor;
			
		} 	else 	{
			impares++;
		} 
			if (valor > maiorNum) {
			maiorNum = valor;
		}
			if (valor > maiorNum) {
			maiorNum = valor; 
		}
	}
		printf("Digite um n�mero: ");
		scanf("%i",&valor);
		
	}
	
	if (contGeral == 0){
		printf("N�o foi um n�mero positivo.");
	} else {
		medGeral = somaGeral / (float) contGeral;
		medPares = somaPares / (float) pares;
		
	printf("Quantida de pares: %.1i \n", pares);
	printf("Quantida de �mpares: %.1i \n", impares);
	printf("M�dia dos n�meros pares: %.1f \n", medPares);
	printf("M�dia geral: %.1f \n", medGeral);
	printf("O maior n�mero �: %.1i", maiorNum);
	printf("O menor n�mero �: %.1i", menorNum);
	}
 return 0;	
}
