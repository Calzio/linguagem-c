#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <ctype.h>

int main () {
	setlocale(LC_ALL, "");
	
	int cont = 0;
	float nota, soma = 0, med;
	char resp;
	
	do {
		printf("Digite uma nota: ");
		scanf("%f",&nota);
		
		fflush(stdin);
		
		system("cls || clear");
		printf("Escolha uma das op��es abaixo: \n");
		printf("S - Inserir mais uma nota: \n");
		printf("P - Ver quantidade de notas inseridas: \n");
		printf("N - Calcular a m�dia aritm�tica: \n");
		printf("Resposta: \n");
		scanf("%c",&resp);
		resp = toupper(resp);
		
		soma += nota;
		cont++;
		
		switch(resp) {
			case 'S' :
				system("cls || clear");
			break;
				case 'P' :
					printf("\nQuantidade de notas inseridas: %i \n", cont);
					sleep(5);
					system("cls || clear");
				break;
			case 'N' :
				system("cls || clear");
			break;
				default:
					printf("Op��o inv�lida! \n");
					sleep(5);
					system("cls || clear");
		}
	} while (resp != 'N');
	
	med = soma / cont;
	
	printf("\n=== Exibindo resultados ===\n");
	printf("M�dia: %.1f \n", med);
	
	return 0;
}
