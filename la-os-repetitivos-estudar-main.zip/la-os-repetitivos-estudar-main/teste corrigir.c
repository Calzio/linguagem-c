#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <ctype.h>

int main () {
	setlocale(LC_ALL, "");
	
	int idade;
	char opcoes, nome, sexo;
	float salario, salariodeMulheresAPartirDe = 5000;
	
	do {
	
	fflush(stdin);
		
	printf("Digite o nome: ");
	scanf("%c",&nome);
	
	fflush(stdin);
	
	printf("Digite a idade : ");
	scanf("%i",&idade);
	
	fflush(stdin);
	
	printf("Digite o seu sexo: ");
	scanf("%c",&sexo);
	
	fflush(stdin);
	
	printf("Digite seu sal�rio: ");
	scanf("%f",&salario);
	
	fflush(stdin);
	
	printf("C�digos | Descri��o\n");
	printf("1 | Adicionar pessoas\n");
	printf("2 | Exibir resultado\n");
	
	printf("Digite o c�digo: ", opcoes);
	scanf("%c",&opcoes);
				
	switch (opcoes) {
		case 1 :
			system("cls || clear");
			break;
				case 2 :
					system("cls || clear");
					break;
			default:
				printf("Op��o inv�lida;");
				system("cls || clear");
	}
	} while (opcoes = 2);
	return 0;
}
