#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <locale.h>
#define TAM 6

int main () {
	setlocale(LC_ALL, "");
	
	int i, num[TAM], par = 0, impar = 0;
	
	for (i = 0; i < TAM; i++) {
	printf("Digite um n�mero: ");
	scanf("%i",&num[i]);

		if (i % 2 == 0) {
			par = num[i];
	
		} 	else 	{
			impar = num[i];		
		}
	}

system("cls || clear");

printf("Os n�meros pares s�o: %d\n", par);
printf("Os n�meros �mpares s�o: %d\n", impar);
	return 0;
}	
