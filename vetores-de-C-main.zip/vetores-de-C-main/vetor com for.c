#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <locale.h>

int main () {
	int vetor[5];
	int i;
	
	printf("Digite os elementos do vetor:\n");
	for (i = 0; i < 5; i++) {
		printf("Elemento %d: ", i + 1);
		scanf("%d",&vetor[i]);
	}
	return 0;
}
