#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <locale.h>

int main () {
	int numeros[5];
	numeros[0]=1;
	numeros[1]=2;
	numeros[2]=3;
	numeros[3]=4;
	numeros[4]=5;
	numeros[5]=6;
	
	printf("%i", numeros[0]);
	printf("%i", numeros[1]);
	printf("%i", numeros[2]);
	printf("%i", numeros[3]);
	printf("%i", numeros[4]);
	printf("%i", numeros[5]);
	
}
