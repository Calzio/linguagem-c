#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <locale.h>
#define TAM 3

int main () {
	setlocale(LC_ALL, "");
	
	float nota[TAM], media= 0, soma= 0;
	int i;
fflush(stdin);

	for (i = 0; i < TAM; i++) {
fflush(stdin);

	printf("Digite a %d� nota: ", i+1);
	scanf("%f",&nota[i]);

		soma += nota[i];
	}

	 media = soma /(float) TAM;
	
	printf("Exibindo notas:\n");
	
	for (i = 0; i < 3; i++) {
	
	 printf("%d� nota: %.1f \n", i+1, nota[i]);
}
	 printf("\nM�dia: %.1f \n", media);
	 
	return 0;	
}
