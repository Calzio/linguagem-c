#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

#define Sz 6

int main () {
	setlocale(LC_ALL,"");
	int numeros[Sz];
	int i, quantP = 0, quantI = 0;
	
	printf("=== Solicitando dados para o usu�rio === \n");
	for(i=0;i < Sz; i++) {
		printf("Digite o %i� n�mero: ", i+1);
		scanf("%i",&numeros[i]);
		
		if(numeros[i] % 2 == 0) {
			quantP++;
		} else {
			quantI++;
		}
	}
	printf("\n== Resultados == \n");
	for(i = 0; i < Sz; i ++) {
		printf("%i� numero: %i \n", i+1, numeros[i]);
	}
	
	printf("A quantidade de Pares foi: %i\n", quantP);
	printf("A quantidade de �mpares foi: %i\n", quantI);
	return 0;
}
