#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

#define P 2

int main() {
	int idade[P], i;
	char nome[P][200];
	
	printf("==Preencha seus dados abaixo==\n");
	for (i = 0; i < P; i++){
	
	printf("Digite o seu nome: ");
		scanf("%s",&nome[i]);
			fflush(stdin);
			
	printf("Digite sua idade: ");
		scanf("%i",&idade[i]);
	}
			fflush(stdin);
	printf("Exibindo resultados: \n");
			
	
	for(i = 0; i < P; i++){
			fflush(stdin);
		printf("Digite o seu nome: %s\n",nome[i]);
	
		printf("Digite sua idade: %i\n",idade[i]);
		
	}
	return 0;
}
