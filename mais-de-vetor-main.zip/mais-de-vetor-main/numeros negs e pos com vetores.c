#include <locale.h>
#include <stdlib.h>

#define Sz 10

int main () {
	setlocale(LC_ALL,"");
	int numeros[Sz];
	int i, numerosNeg = 0, numerosPos = 0, soma = 0;
	
	printf("=== Solicitando dados para o usu�rio === \n");
	for(i=0;i < Sz; i++) {
		printf("Digite o %i� n�mero: ", i+1);
		scanf("%i",&numeros[i]);
		
		if(numeros[i] > 0) {
			numerosPos+=numeros[i];
		} else {
			numerosNeg++;
		}
	}
	printf("\n== Resultados == \n");
	for(i = 0; i < Sz; i ++) {
		printf("%i� numero: %i \n", i+1, numeros[i]);
	}
	
	
	printf("A quantidade de n�meros negativos foi: %i\n", numerosNeg);
	printf("A quantidade de n�meros positivos foi: %i\n", numerosPos);
	return 0;
}
