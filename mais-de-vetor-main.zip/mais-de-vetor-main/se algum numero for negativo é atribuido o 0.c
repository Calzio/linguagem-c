#include <locale.h>
#include <stdlib.h>

#define Sz 2

int main () {
	setlocale(LC_ALL,"");
	float numeros[Sz];
	int i, numerosNeg = 0;
	
	printf("=== Solicitando dados para o usu�rio === \n");
	for(i=0;i < Sz; i++) {
		printf("Digite o %i� n�mero: ", i+1);
		scanf("%f",&numeros[i]);
		
		if(numeros[i] < 0){
			numeros[i]=0;
		}
	}
	printf("\n== Resultados == \n");
	for(i = 0; i < Sz; i ++) {
		printf("%i� numero: %.1f \n", i+1, numeros[i]);
	}
	
	return 0;
}
