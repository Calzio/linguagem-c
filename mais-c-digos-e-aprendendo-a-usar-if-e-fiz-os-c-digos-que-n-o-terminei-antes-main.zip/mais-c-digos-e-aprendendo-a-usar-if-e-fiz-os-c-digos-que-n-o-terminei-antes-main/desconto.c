#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
	setlocale(LC_ALL, "");
	
	float valor, desconto, valorFinal;
	
	printf("Digite um valor: ");
	scanf("%f",&valor);
	
	desconto = valor * 0.1;
	valorFinal = valor - desconto;
	
	system("cls || clear");
	
	printf("\n== Valor ==\n");
	printf("Valor informado: R$ %.2f \n", valor);
	printf("Desconto: %.2f \n", desconto);
	printf("Valor total: %.2f \n", valorFinal);
	
	return 0;
	
}
