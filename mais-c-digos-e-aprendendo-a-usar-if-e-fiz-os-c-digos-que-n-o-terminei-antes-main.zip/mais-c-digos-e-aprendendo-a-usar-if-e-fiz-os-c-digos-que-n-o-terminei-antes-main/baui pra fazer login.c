#include <stdio.h>
#include <stdlib.h>

int main () {
	char loginSalvo[200] = "Calcio";
	char senhaSalva[200] = "123456";
	char login[200];
	char senha[200];
	
	printf("Digite o login: ");
	scanf("%s",&login);
	
	printf("Digite a senha: ");
	scanf("%s",&senha);
	
	// if (Login == loginSalvo && senha == senhaSalva)
	// && -> e -> and
	// || -> ou -. or
	// strcmp -> comparar strings
	if (strcmp(login, loginSalvo) == 0 && strcmp(senha, senhaSalva) == 0) {
     printf("Bem vindo!");		
	} else {
		printf("Acesso negado!");
	}
	
	return 0;
}
