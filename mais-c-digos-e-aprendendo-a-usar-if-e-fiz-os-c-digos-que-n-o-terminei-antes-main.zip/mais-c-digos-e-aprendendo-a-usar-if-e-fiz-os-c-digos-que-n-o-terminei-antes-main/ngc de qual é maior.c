#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main () {
	setlocale(LC_ALL, "");

	int numero1, numero2;
	float media, soma, produto;
	
	printf("Digite o primeiro n�mero: ");
	scanf("%i",&numero1);
	
	printf("Digite o segundo n�mero: ");
	scanf("%i",&numero2);
	
	media = (numero1 + numero2) / 2;
	produto = numero1 * numero2;
	soma = numero1 + numero2;
	
	printf("M�dia:%.2f \n", media);
	printf("Produto:%.2f \n", produto);
	printf("Soma:%.2f \n", soma);
	
	if(numero1 > numero2) {
		printf("O 1� n�mero tem o maor valor \n");
	} else {
		printf("O 2� n�mero tem o maior valor");
	}
	
	return 0;
}
