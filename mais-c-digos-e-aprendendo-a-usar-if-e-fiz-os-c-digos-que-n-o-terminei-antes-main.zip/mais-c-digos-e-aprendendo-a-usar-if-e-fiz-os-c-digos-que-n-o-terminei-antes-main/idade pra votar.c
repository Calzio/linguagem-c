#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
	setlocale(LC_ALL, ""); 
	float idade;
		
	printf("Digite sua idade: ");
	scanf("%f",&idade);
	
	if (idade <= 17 ) {
	    printf("N�o precisa votar.");
	} else if (idade >= 18 && idade <= 64) {
		printf("Tem que votar.");
	} else {
		printf("J� passou do tempo que precisaria se preocupar com isso.");
	}
	
	return 0;
	}
