#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
	setlocale(LC_ALL, "");
	
	float nota1, nota2, nota3, nota4, media;
	char nome[200];
	int idade;
	
	system("cls || clear");
	
	printf("Digite o nome do encarecido aluno: ");
	scanf("%s", &nome);
	
	printf("Digite a idade do aluno: ");
	scanf("%i", &idade);
	
	printf("Digite a primeira nota: ");
	scanf("%f", &nota1);
	
	printf("Digite a segunda nota: ");
	scanf("%f", &nota2);
		
	printf("Digite a terceira nota: ");
	scanf("%f", &nota3);	
	
	printf("Digite a quarta nota: ");
	scanf("%f", &nota4);
		
	media = (nota1 + nota2 + nota3 + nota4) / 4;
		
		printf("\n== Resultados ==\n");
		printf("Nome: %s \n", nome);
		printf("Idade: %i \n", idade);
		printf("Primeira nota: %.2f \n", nota1);
		printf("Segunda nota: %.2f \n", nota2);
		printf("Terceira nota: %.2f \n", nota3);
		printf("Quarta nota: %.2f \n", nota4);
		printf("M�dia: %.2f \n", media);
		
	     if (media >= 6) {
			printf("Aprovado!");
		} else {
			printf("Reprovado!");
		}

    return 0;
}
