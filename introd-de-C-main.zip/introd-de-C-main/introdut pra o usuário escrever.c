#include <stdio.h>

int main() { 
// Declarando vari�veis
	char nome[200]; 
	char sexo;
	int idade;  
	float peso;
		
// Slicitando dados para o uru�rio.
	printf("Digite seu nome: ");
	scanf("%s",&nome);
	
	fflush(stdin); // � o limpar
	
	printf("Digite seu sexo: ");
	scanf("%c",&sexo);
	
	fflush(stdin);
	
	printf("Digite sua idade: ");
	scanf("%i",&idade);
	
	printf("Digite seu peso: ");
	scanf("%f",&peso);
	
	
	// Exibino resultados.
	printf("\n=== Exibindo resultados ===\n");
	printf("Nome: %s \n", nome); // %s -> string ->  cadeia
	printf("Sexo;: %c \n", sexo); // %c -> character -> caracter
	printf("Idade: %i \n", idade); // %i -> inteiro
	printf("Peso: %f \n", peso); // %f -> float -> real
	
	return 0;
}
