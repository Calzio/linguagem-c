#include <stdio.h>

int main() {
	// Declarando vari�veis
	char nome[200] = "Marta"; // Cadeia
	char sexo = 'F'; // Caracter, �spas simples(') pra caracteres
	// e as aspas duplas(") pra cadeia
	int idade = 20; // Inteiro 
	float peso = 58.400; // Real
	
	// Exibino resultados.
	printf("\n=== Exibindo resultados ===\n");
	printf("Nome; %s \n", nome); // %s -> string ->  cadeia
	printf("Sexo; %c \n", sexo); // %c -> character -> caracter
	printf("Idade; %i \n", idade); // %i -> inteiro
	printf("Peso: %f \n", peso); // %f -> float -> real
	
	return 0;
}
