#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <ctype.h>

int main () {
	
	setlocale(LC_ALL, "");
	
	int codigo, familiasQueResponderam = 0, quantidadeDeFilhos = 0, contadorDeSalario = 0, mediaDoNumeroDeFilhos = 0;
	int contadorDerespostas = 0, somaDaquantidadeDeFilhos = 0;
	char sexo;
	float salario = 0, mediaDoSalario = 0, somaDoSalario = 0, maiorSalario = INT_MIN, menorSalario = INT_MAX;
	
	do {
	fflush(stdin);
		printf("Digite quantos filhos voc� tem: ");
		scanf("%i",&quantidadeDeFilhos);
	fflush(stdin);
		printf("Digite o sal�rio: ");
		scanf("%f",&salario);
	
	fflush(stdin);
	
	system("cls || clear");
	
	fflush(stdin);
		printf("C�digo | Descri��o\n");
		printf("  1    | Add familia\n");
		printf("  2    | Exibir resultados e sair\n");
		printf("Digite o c�digo desjado: ");
		scanf("%i",&codigo);
	
		fflush(stdin);
	if (salario > maiorSalario) {
		maiorSalario = salario;
			system("cls || clear");

	} if (salario < menorSalario) {
		menorSalario = salario;
			system("cls || clear");
}
	fflush(stdin);
 	contadorDeSalario++;
 	familiasQueResponderam++;
 	
	} while (codigo != 2);

	somaDoSalario += salario;
	somaDaquantidadeDeFilhos += quantidadeDeFilhos;
	mediaDoSalario = somaDoSalario / contadorDeSalario;
	mediaDoNumeroDeFilhos = somaDaquantidadeDeFilhos / (float) familiasQueResponderam;
	system("cls || clear");
 	fflush(stdin);
 		
	printf("M�dia do salario da popula��o: %.1f \n", mediaDoSalario);
	printf("Maior salario do grupo: %.1f \n", maiorSalario);
	printf("Menor salario do grupo: %.1f \n", menorSalario);
	printf("Quantidade de respostas: %.1i \n", familiasQueResponderam);	
	printf("M�dia de filhos: %.1i", mediaDoNumeroDeFilhos);

	return 0;
}
