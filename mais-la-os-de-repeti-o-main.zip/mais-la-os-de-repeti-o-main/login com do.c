#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>
#include <stdbool.h>
int main () {
	
	setlocale(LC_ALL, "");
	
	char senhaR[200] = "123456", senha[200];
	char loginR[200] = "Caio", login[200];
	bool loginC, senhaC;
	
	do {
	
			fflush(stdin);
	printf("Digite o login: ");
		scanf("%s",&login);
	
		fflush(stdin); 
	
	printf("Digite a senha: ");
		scanf("%s",&senha);
	
		fflush(stdin); 
		
		loginC = strcmp(login, loginR) == 0;
		senhaC = strcmp(senha, senhaR) == 0;
		sleep(1);
			
			// ou tamb�m strcmp(login, loginR) != 0 && strcmp(senha, senhaR) != 0
		} while(!loginC || !senhaC);
			
	printf("Seja Bem-vindo.");
	
	
	return 0;
}
