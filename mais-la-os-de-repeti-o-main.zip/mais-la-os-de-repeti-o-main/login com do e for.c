#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>
#include <stdbool.h>
int main () {
	
	setlocale(LC_ALL, "");
	
	int s;
	char senhaR[200] = "123456", senha[200];
	char loginR[200] = "Caio", login[200];
	bool loginC, senhaC;
	
			for(s = 1; s <=3; s++) {
			fflush(stdin);
	printf("Digite o login: ");
		scanf("%s",&login);
	
		fflush(stdin); 
	
	printf("Digite a senha: ");
		scanf("%s",&senha);
	
		fflush(stdin); 
		
		if (strcmp(login, loginR) != 0) {
			printf("Login incorreto.");
				printf("Tentativa %i de 3 \n", s);
		} else if (strcmp(senha, senhaR) != 0) {
			printf("Senha incorreto.");
				printf("Tentativa %i de 3 \n", s);
		} else {
			("Acesso autorizado!");
			break;
		}
		system("cls || clear");
	}
			
	printf("Seja Bem-vindo.");
	
	
	return 0;
}
