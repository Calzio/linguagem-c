#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <ctype.h>
int main () {
  setlocale(LC_ALL,"");
  int i;
  float notas, soma, media;
  
  	fflush(stdin);
  	
  for(i = 1; i<=4; i++) {
 	printf("Digite o %i� nota: ", i);
 	scanf("%f",&notas);
 	
 	soma = soma + notas ;
	}
	media = soma / (float) 4;
	
	 printf("A m�dia �: %.1f \n", media);
	 if (media >= 6 ) {
	 	printf("Aprovado!");
	 } else {
	 	printf("Reprovado.");
	 }
	 
return 0;
}
