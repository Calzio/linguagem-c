#include <stdlib.h>
#include <stdio.h>
#include <locale.h>


int main () {
	int i;
	for (i = 1; i <= 10;i++) {
		printf ("%d \n", i);
	}
	
	return 0;
	
}
