#include <stdlib.h>
#include <stdio.h>
#include <locale.h>

int main () {
	int j, i;
	for (j = 10; j >= 1;j--) {
		printf ("%d \n", j);
	}
	
	return 0;
}
