#include <stdlib.h>
#include <stdio.h>
#include <locale.h>

int main () {
  setlocale(LC_ALL,"");
 int i;
 
 printf("mostrando os n�meros pares entre 100 e 200: \n");
 for(i = 100; i<=200; i++) {
 	if (i % 2 == 0) {
        printf("%d \n", i);
      }
  }
  
 return 0;
}
