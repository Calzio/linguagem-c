#include <stdlib.h>
#include <stdio.h>
#include <locale.h>

int main () {
  setlocale(LC_ALL,"");
	int i, j;
	
	printf("Escolha um n�mero para ser multiplicado \n");
	scanf("%i",&j);
	
	for (i = 1; i <= 10;i++) {
		printf ("%i x %d = %d \n", j, i, j * i);
	}
	
	return 0;
	
}
