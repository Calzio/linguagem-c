#include <stdlib.h>
#include <stdio.h>
#include <locale.h>

int main () {
  setlocale(LC_ALL,"");
 int i;
 
 printf("mostrando os n�meros pares entre 100 e 200: \n");
 for(i = 1; i<=5; i++) {
 	if (i % 2 == 0) {
        printf("Os pares s�o : %d \n", i);
      } else if (i % 2 != 0) {
        printf("Os �mpares s�o : %d \n", i);
  }
  
 return 0;
 
 }
