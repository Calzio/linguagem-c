#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <ctype.h>
int main () {
  setlocale(LC_ALL,"");
  int i, numero, soma = 0;
  
  
  	fflush(stdin);
  	
  for(i = 1; i<=5; i++) {
 	printf("Digite o %i� n�mero: ", i);
 	scanf("%i",&numero);
 	
 	soma = soma + numero ;
	 
	 }
	 printf("A soma �: %i \n", soma);
	 
return 0;
}
